// ═══════════════════════════════════════════════
//  config.js — Bot Configuration
//  Edit sesuai kebutuhan sebelum deploy
// ═══════════════════════════════════════════════

const config = {
  // ─── Prefix Command ───────────────────────────
  // usePrefix: true  → semua command wajib pakai prefix
  // usePrefix: false → semua command bisa tanpa prefix (dan tetap bisa pakai prefix)
  usePrefix: false,
  prefix: '',     // Bisa diganti: / \ - _ $ # . ! ? dll

  // ─── Owner Numbers (format: 628xxxxx tanpa +) ─
  ownerNumber: ['6285823614537'],
  // LID owner (format internal WA) — lihat di console log saat ada pesan masuk
  // Contoh dari log: [CMD] 57260671819853@lid → menu
  ownerLid: ['57260671819853@lid'],

  // ─── Bot Info ─────────────────────────────────
  botName: 'Zhuaxin',
  botVersion: '0.1',
  botDeveloper: 'Akito Hidata',
groqApiKey: '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',
  // ─── Channel ID untuk .playch ─────────────────
  // Format: 120363xxxxxxxx@newsletter
  channelId: '120363405040255836@newsletter',  // isi dengan ID channel WhatsApp kamu

  // ─── Sticker Watermark ────────────────────────
  // stickerPack   → baris atas sticker (nama/judul)
  // stickerAuthor → baris bawah sticker (pembuat)
  stickerPack: '✦ Hidata/Taufik/Lirenxin ✦',
  stickerAuthor: '᯾ 6285823614537 | 6285745208985 ᯾',

  // ─── GitHub Backup ───────────────────────────────
  githubToken: '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',
  githubUser:  'akitohidata211228',
  githubRepo:  'Zhuaxin',

  // ─── Session Folder ───────────────────────────
  sessionDir: './sessions',

  // ─── Pairing Timeout (ms) ─────────────────────
  // 3 menit = 180000 ms
  pairingTimeout: 180000,

  // ─── Reconnect Settings ───────────────────────
  maxReconnectAttempts: 5,
  reconnectDelay: 5000,

  // ─── Logger Level ─────────────────────────────
  // 'silent' | 'fatal' | 'error' | 'warn' | 'info' | 'debug' | 'trace'
  logLevel: 'silent',
}

export default config
